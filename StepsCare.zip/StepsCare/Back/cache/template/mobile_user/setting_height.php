<?php include(pe_tpl('header.html'));?>
<div class="pagetop">
	<div class="fh"><a href="user.php?mod=setting&act=base"></a></div>
	<div><?php echo $menutitle ?></div>

</div>
<div class="main">
	<form method="post" id="form">
	<div class="zc_box2">
		<div class="zc_list">
			<div class="zc_name">height</div>
			<div class="zc_text"><input type="text" name="height" value="<?php echo $info['height'] ?>" /></div>
		</div>
	</div>	
	<div class="loginbtn"  style="margin:20px 10px;">
		<input type="hidden" name="pe_token" value="<?php echo $pe_token ?>" />
		<input type="hidden" name="pesubmit" />
		<input type="button" value="Submit" />
	</div>
	</form>
</div>
<script type="text/javascript">
$(function(){
	$(":button").click(function(){
		app_submit("<?php echo pe_nowurl() ?>", function(json){
			if (json.result) app_open('user.php?mod=setting&act=height', 1000);
		});
	})
})
</script>
<?php include(pe_tpl('footer.html'));?>