
<?php include(pe_tpl('header.html'));?>
<div class="pagetop">
	<div class="fh"><a href="user.php"></a></div>
	<div><?php echo $menutitle ?></div>

</div>
<div class="fenhong_box">

	<div class="">Today's steps</div>
	<div class="fh_money">8</div>
</div>
<div class="main">
	<div class="tx_tt"><i></i>Daily Steps</div>
	<?php if(!count($info_list)):?>
	<div class="nodata">
		<div class="nodata_img"></div>
		<div class="nodata_tip">暂无信息</div>
	</div>
	<?php endif;?>
	<div class="jf_box" style="margin-top:0">
		
		<div class="jf_list">
			<div class="jifen_l">
			    <span class="num cgreen">consume：6cal</span>
				<p><span class="num">Not meeting standards</span></p>
				<span class="c999">2023-06-09</span>
			</div>
			<div class="jifen_r">
				<p>
				
				<span class="num cgreen">+25</span>
				
				</p>
			</div>
			<div class="clear"></div>
		</div>
	
	</div>
	<div class="fenye mab10"><?php echo $db->page->html ?></div>
</div>
<?php include(pe_tpl('footer.html'));?>