
<?php include(pe_tpl('header.html'));?>
<div class="pagetop">
	<div class="fh"><a href="user.php"></a></div>
	<div><?php echo $menutitle ?></div>
</div>
<div class="main">
	<form method="post" id="form">
	<div class="zc_box2">
		<div class="zc_list sk_box">
			<a href="user.php?mod=setting&act=tname">
				<span class="sk_name">Name</span>
				<div class="info_tt"><?php echo $info['user_tname'] ?></div>
				<i></i>
			</a>
		</div>
		<div class="zc_list sk_box">
			<a href="user.php?mod=setting&act=phone">
				<span class="sk_name">tel</span>
				<div class="info_tt"><?php echo $info['user_phone'] ?></div>
				<i></i>
			</a>
		</div>
		<div class="zc_list sk_box">
			<a href="user.php?mod=setting&act=email">
				<span class="sk_name">E-mail</span>
				<div class="info_tt"><?php echo $info['user_email'] ?></div>
				<i></i>
			</a>
		</div>
		<div class="zc_list sk_box">
			<a href="user.php?mod=setting&act=age">
				<span class="sk_name">age</span>
				<div class="info_tt"><?php echo $info['age'] ?></div>
				<i></i>
			</a>
		</div>
		<div class="zc_list sk_box">
			<a href="user.php?mod=setting&act=height">
				<span class="sk_name">height</span>
				<div class="info_tt"><?php echo $info['height'] ?>cm</div>
				<i></i>
			</a>
		</div>
		<div class="zc_list sk_box">
			<a href="user.php?mod=setting&act=weight">
				<span class="sk_name">weight</span>
				<div class="info_tt"><?php echo $info['weight'] ?>kg</div>
				<i></i>
			</a>
		</div>
		<div class="zc_list sk_box">
			<a>
				<span class="sk_name">target</span>
				<div class="info_tt">60step</div>
			
			</a>
		</div>
		<div class="zc_list sk_box">
			<a>
				<span class="sk_name">Sleep time</span>
				<div class="info_tt">
				    <?php if($info['age']>17):?>
				    7-9 hours
				    <?php endif;?>
				    <?php if($info['age']<=17):?>
				    8-9 hours
				    <?php endif;?>
				</div>
			
			</a>
		</div>
		
		<div class="zc_list sk_box">
			<a href="user.php?mod=setting&act=pw">
				<span class="sk_name">password</span>
				<div class="info_tt">modify</div>
				<i></i>
			</a>
		</div>
		
	</div>
	</form>
</div>
<div class="fb_btn1"><a href="javascript:user_logout();">Exit current account</a></div>
<script type="text/javascript">
function user_logout() {
	app_getinfo('user.php?mod=do&act=logout', function(json){
		if (json.result) {
			app_open('user.php', 1000);
		}
	});
}
</script>
<style type="text/css">
.info_tt{ text-align:right}
</style>
<?php include(pe_tpl('footer.html'));?>