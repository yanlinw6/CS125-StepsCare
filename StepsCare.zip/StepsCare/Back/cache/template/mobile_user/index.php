
<?php include(pe_tpl('header.html'));?>
<div class="content" style="margin-bottom:62px;">
	<div class="user_info">
		<div class="user_tt">Personal Center</div>
		<div class="user_tx_box">
			<div class="user_tx">
				<a href="user.php?mod=setting&act=logo"><img src="<?php echo $user_logo ?>" /></a>
			</div>
			<?php if(pe_login('user')):?>
			<div class="user_text">
				<div class=""><?php echo $_s_user_nickname ?></div>
			</div>
			<?php else:?>
			<div class="center mat20 font16">
				<a href="user.php?mod=do&act=login">login</a>　|　<a href="user.php?mod=do&act=register">reg</a>
			</div>
			<?php endif;?>
		</div>
		
	</div>
	<div class="side_all">
		<div class="side_fh1">
		    <div style="width:200px; margin:0px auto;height:40px;">
			    
			</div>
			<div style="width:200px; margin:0px auto;height:200px;border-radius:100px;">
			    <img src="/template/mobile_user/images/sport.png" style="width:200px;border-radius:100px;">
			</div>
			
			<div style="width:200px; margin:0px auto;height:20px;">
			    
			</div>
			<div style="width:200px; margin:0px auto;height:20px;text-align:center;">
			    Today's steps：<span id="step">25</span>
			</div>
			
			<div style="width:200px; margin:0px auto;height:20px;">
			    
			</div>
			<div style=" margin:0px auto;">
			    <img src="/template/mobile_user/images/chart1.png" style="width:360px;">
			</div>
			<div style="width:200px; margin:0px auto;height:20px;">
			    
			</div>
		</div>
		
		<div class="ck_nav mat10">
			<ul>
			<li><a href="user.php?mod=pointlog"><i class="ck_i2"></i><span>Daily Steps</span><p></p></a></li>
			<li><a href="user.php?mod=setting&act=base"><i class="ck_i4"></i><span>Accounts</span><p></p></a></li>
			<li><a href="<?php echo pe_url('article-list-1') ?>"><i class="ck_i6"></i><span>Announcement</span><p></p></a></li>
			</ul>
			<div class="clear"></div>
		</div>
		<div class="ck_nav_xian"></div>
		
	</div>
</div>
<?php include(pe_tpl('footer.html'));?>