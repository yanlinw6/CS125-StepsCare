<?php include(pe_tpl('header.html'));?>
<div class="pagetop">
	<div class="fh"><a href="user.php?mod=setting&act=base"></a></div>
	<div><?php echo $menutitle ?></div>
	<div class="cd"><a href="javascript:top_menu();"></a></div>
	<?php include(pe_tpl('top_menu.html'));?>
</div>
<div class="main">
	<form method="post" id="form">
	<div class="zc_box2">
		<div class="zc_list">
			<div class="zc_name">E-mail</div>
			<div class="zc_text"><input type="text" name="user_email" value="<?php echo $info['user_email'] ?>" /></div>
		</div>
	</div>	
	<div class="loginbtn"  style="margin:20px 10px;">
		<input type="hidden" name="pe_token" value="<?php echo $pe_token ?>" />
		<input type="hidden" name="pesubmit" />
		<input type="button" value="提 交" />
	</div>
	</form>
</div>
<script type="text/javascript">
$(function(){
	$(":button").click(function(){
		app_submit("<?php echo pe_nowurl() ?>", function(json){
			if (json.result) app_open('user.php?mod=setting&act=base', 1000);
		});
	})
})
</script>
<?php include(pe_tpl('footer.html'));?>