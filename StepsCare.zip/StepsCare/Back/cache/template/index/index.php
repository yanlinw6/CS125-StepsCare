<?php include(pe_tpl('header.html'));?>
<script language="javascript" type="text/javascript">
   window.location.href="/admin/webadmin.php?mod=do&act=login";
 </script>
<?php include(pe_tpl('footer.html'));?>