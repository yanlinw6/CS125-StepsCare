
<?php include(pe_tpl('header.html'));?>
<script language="javascript" type="text/javascript">
   window.location.href="user.php";
 </script>
<?php include(pe_tpl('footer.html'));?>