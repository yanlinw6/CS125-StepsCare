
<div class="<?php echo $mod=='index' ? 'top_tc' : 'top_menu' ?>" id="top_menu">
	<ul>
	<li><a href="<?php echo $pe['host_root'] ?>"><i class="top_tb1"></i><span>首页</span></a></li>
	<li><a href="<?php echo pe_url('category') ?>"><i class="top_tb2"></i><span>分类</span></a></li>
	<li><a href="<?php echo pe_url('cart') ?>"><i class="top_tb3"></i><span>购物车</span></a></li>
	<li><a href="<?php echo $pe['host_root'] ?>user.php"><i class="top_tb4"></i><span>我的</span></a></li>
	</ul>
	<div class="clear"></div>
</div>