<?php include(pe_tpl('header.html','admin'));?>
<div class="right">
	<div class="now">

		
		
		<div class="clear"></div>
	</div>
	<div class="right_main">
		<form method="post" id="form">
		<table width="100%" border="0" cellspacing="0" cellpadding="0" class="list">
		<tr>
	        <th class="bgtt">ID</td>
			<th class="bgtt">标题</td>
			<th class="bgtt" width="110">操作</th>
		</tr>
		<?php foreach($info_list as $k=>$v):?>
		<tr>
			<td><?php echo $v['id'] ?></td>
			<td class="aleft"><?php echo $v['title'] ?></td>
			<td>
			
				<a href="webadmin.php?mod=lunwens&act=edit&id=<?php echo $v['id'] ?>&<?php echo pe_fromto() ?>" class="admin_edit mar3">查看</a>
			
			
			</td>
		</tr>
		<?php endforeach;?>
		</table>
		</form>
	</div>
	<div class="right_bottom">
		
		<span class="fr fenye"><?php echo $db->page->html ?></span>
		<div class="clear"></div>
	</div>
</div>
<?php include(pe_tpl('footer.html','admin'));?>