<?php include(pe_tpl('header.html','admin'));?>
<div class="right">
	<div class="now">

		<a href="webadmin.php?mod=lunwen&act=add" <?php if($act=='add'):?>class="sel"<?php endif;?> id="fabu">添加论文</a>
		<?php if($act=='edit'):?><a href="javascript:;" class="sel">修改信息</a><?php endif;?>
		<div class="clear"></div>
	</div>
	<div class="right_main">
		<form method="post" id="form">
		<table width="100%" border="0" cellspacing="0" cellpadding="0" class="list">
		<tr>
	        <th class="bgtt">ID</td>
			<th class="bgtt">标题</td>
			<th class="bgtt" width="110">操作</th>
		</tr>
		<?php foreach($info_list as $k=>$v):?>
		<tr>
			<td><?php echo $v['id'] ?></td>
			<td class="aleft"><?php echo $v['title'] ?></td>
			<td>
				<?php if($v['class_id'] != 1):?>
				<a href="webadmin.php?mod=lunwen&act=edit&id=<?php echo $v['id'] ?>&<?php echo pe_fromto() ?>" class="admin_edit mar3">修改</a>
				<a href="webadmin.php?mod=lunwen&act=del&id=<?php echo $v['id'] ?>&token=<?php echo $pe_token ?>" class="admin_del" onclick="return pe_cfone(this, '删除')">删除</a>
				<?php else:?>
				-
				<?php endif?>
			</td>
		</tr>
		<?php endforeach;?>
		</table>
		</form>
	</div>
	<div class="right_bottom">
		
		<span class="fr fenye"><?php echo $db->page->html ?></span>
		<div class="clear"></div>
	</div>
</div>
<?php include(pe_tpl('footer.html','admin'));?>