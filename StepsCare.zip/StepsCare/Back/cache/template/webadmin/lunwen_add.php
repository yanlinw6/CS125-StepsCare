<?php include(pe_tpl('header.html','admin'));?>
<div class="right">
	<div class="now">
		<a href="javascript:;" class="sel"><?php echo $menutitle ?><i></i></a>
		<div class="clear"></div>
	</div>
	<div class="right_main">
		<form method="post">
		<table width="100%" border="0" cellspacing="0" cellpadding="0" class="wenzhang mat20 mab20">
	
		<tr>
			<td align="right" width="150">标题：</td>
			<td><input type="text" name="info[title]" value="<?php echo $info['title'] ?>" class="inputall input200" /></td>
		</tr>
		<tr>
			<td align="right" width="150">链接：</td>
			<td><input type="text" name="info[url]" value="<?php echo $info['url'] ?>" class="inputall input200" /></td>
		</tr>
		
		<tr>
			<td>&nbsp;</td>
			<td>
				<input type="hidden" name="pe_token" value="<?php echo $pe_token ?>" />
				<input type="submit" name="pesubmit" value="提 交" class="tjbtn" />
			</td>
		</tr>
		</table>
		</form>
	</div>
</div>
<?php include(pe_tpl('footer.html','admin'));?>