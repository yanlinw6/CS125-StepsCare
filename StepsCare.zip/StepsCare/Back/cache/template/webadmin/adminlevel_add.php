<?php include(pe_tpl('header.html','admin'));?>
<div class="right">
	<div class="now">
		<a href="javascript:;" class="sel"><?php echo $menutitle ?><i></i></a>
		<div class="clear"></div>
	</div>
	<div class="right_main">
		<form method="post">
		<table width="100%" border="0" cellspacing="0" cellpadding="0" class="wenzhang mat20 mab20">
		<tr>
			<td align="right" width="150">权限名称：</td>
			<td><input type="text" name="info[adminlevel_name]" value="<?php echo $info['adminlevel_name'] ?>" class="inputall input200" /></td>
		</tr>
		<tr>
			<td align="right" valign="top">权限分配：</td>
			<td>
				<?php foreach($modact_list as $k=>$v):?>
				<div class="fl" style="width:120px">
				<table width="100%" border="0" cellspacing="0" cellpadding="0" class="wenzhang" style="margin:0">
				<tr>
					<td class="bgtt"><input type="checkbox" name="modact_all" style="margin-right:8px" /><strong><?php echo $k ?></strong></td>
				</tr>
				<tr>
					<td>
						<?php foreach($v as $kk=>$vv):?>
						<label style="display:inline-block"><input type="checkbox" name="modact[]" value="<?php echo $vv['modact'] ?>" class="inputfix" <?php if(in_array($vv['modact'], $info['adminlevel_modact'])):?>checked="checked"<?php endif;?> /> <?php echo $vv['name'] ?></label>
						<?php endforeach;?>
					</td>
				</tr>
				</table>
				</div>
				<?php endforeach;?>
				<div class="clear"></div>
			</td>
		</tr>
		<tr>
			<td></td>
			<td>
				<input type="hidden" name="pe_token" value="<?php echo $pe_token ?>" />
				<input type="submit" name="pesubmit" value="提 交" class="tjbtn" />
			</td>
		</tr>
		</table>
		</form>
	</div>
</div>
<script type="text/javascript">
$(function(){
	$(":input[name='modact_all']").click(function(){
		if ($(this).is(":checked")) {
			$(this).parents("tr").next("tr").find(":input[name='modact[]']").attr("checked","checked");
		}
		else {
			$(this).parents("tr").next("tr").find(":input[name='modact[]']").removeAttr("checked");
		}
	})
	/*$(":input[name='modact[]']").click(function(){
		var result = true;
		$(this).parents("tr").find("input").each(function(){
			if ($(this).attr("checked") != "checked") result = false;
		})
		if (result == true) {
			$(this).parents("tr").prev("tr").find(":input[name='modact_all']").attr("checked","checked");
		}
		else {
			$(this).parents("tr").prev("tr").find(":input[name='modact_all']").removeAttr("checked");
		}
	})
	$("tr").each(function(){
		var result = true;
		$(this).find(":input[name='modact[]']").each(function(){
			if ($(this).attr("checked") != "checked") result = false;
		})
		if (result == true) {
			$(this).find(":input[name='modact_all']").attr("checked","checked");
		}
		else {
			$(this).find(":input[name='modact_all']").removeAttr("checked");
		}
	})*/
})
</script>
<?php include(pe_tpl('footer.html','admin'));?>