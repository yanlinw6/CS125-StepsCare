<?php include(pe_tpl('header.html','admin'));?>
<div class="right">
	<div class="index_center">
	    
		
		<div class="xtxx_fl mat10">
			
		</div>
		<div class="gzhfs">
			<div class="xt_tt"><span>流量统计</span></div>
			<div class="gzhfs_left mat10">
				<div id="iplog_chart" style="height:280px;width:470px;"></div>
			</div>
			<div class="gzhfs_right">
				<ul>
				<li class="shop_ico3">
					<div class="padd10">
						<h3><?php echo $tongji['iplog_today'] ?></h3>
						<div class="mat5">今日访客</div>
					</div>
				</li>
				<li class="shop_ico3">
					<div class="padd10">
						<h3><?php echo $tongji['user_today'] ?></h3>
						<div class="mat5">今日注册</div>
					</div>
				</li>
			
				<li class="shop_ico3">
					<div class="padd10">
						<h3><?php echo $tongji['iplog_lastday'] ?></h3>
						<div class="mat5">昨日访客</div>
					</div>
				</li>
				<li class="shop_ico3" style="margin-bottom:20px">
					<div class="padd10">
						<h3><?php echo $tongji['user_lastday'] ?></h3>
						<div class="mat5">昨日注册</div>
					</div>
				</li>
			
				</ul>
			</div>
			<div class="clear"></div>
		</div>

		
	</div>
	<div class="index_right">
		<div class="xtxx mab15">
			<div class="xt_tt"><span>官方动态</span></div>
			<div class="gfdt">
				
			</div>
		</div>
		<div class="xtxx mab15">
			<div class="xt_tt"><span>系统信息</span></div>
			<table width="100%" border="0" cellspacing="0" cellpadding="0" class="xx_tb">
			<tr>
				<td align="right" class="c888">系统环境：</td>
				<td><span style="line-height:20px;"><?php echo $php_os ?> <?php echo $php_apache ?> <!--PHP/<?php echo $php_version ?> <a href="webadmin.php?mod=index&act=phpinfo" target="_blank" class="c888">[详情]</a>--></span></td>
			</tr>
			<tr>
				<td align="right" class="c888">PHP版本：</td>
				<td>PHP/<?php echo $php_version ?> <a href="webadmin.php?mod=index&act=phpinfo" target="_blank" class="cblue mal10">[详情]</a></td>
			</tr>
			<tr>
				<td align="right" class="c888">数&nbsp;&nbsp;据&nbsp;库：</td>
				<td><?php echo $php_mysql ?></td>
			</tr>
			</table>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript" src="<?php echo $pe['host_root'] ?>public/js/echarts.min.js"></script>
<script type="text/javascript">
$(function(){
	$.getJSON("http://www.qiye1000.com/", function(json){
		if (json.result) $("#aa").html(json.license_num);
	})
})
// 基于准备好的dom，初始化echarts实例
var iplog_chart = echarts.init(document.getElementById('iplog_chart'));
// 指定图表的配置项和数据
iplog_option = {
    tooltip: {
        trigger: 'axis'
    },
    grid: {
    	top: '15px',
        left: '20px',
        right: '20px',
        bottom: '15px',
        containLabel: true
    },
    xAxis: {
        type: 'category',
        boundaryGap: false,
		axisLabel: {interval: 0},
        data: ['<?php echo implode("','", $chart_x) ?>']
    },
    yAxis: {
        type: 'value'
    },
    series: [
        {
            name:'今日访客',
            type:'line',
            //stack: '总量',
            data:['<?php echo implode("','", $chart_y) ?>'],
			areaStyle: {
				normal: {
					color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
						offset: 0,
						color: 'rgba(30, 144, 255,0.5)'
					}, {
						offset: 1,
						color: 'rgba(30, 144, 255,0.8)'
					}], false)
				}
			},
			itemStyle: {
				normal: {
					color: '#52a9ff'
				}
			},
			lineStyle: {
				normal: {
					width: 1
				}
			}
        }
    ]
};
// 使用刚指定的配置项和数据显示图表。
iplog_chart.setOption(iplog_option);
</script>
<?php include(pe_tpl('footer.html','admin'));?>