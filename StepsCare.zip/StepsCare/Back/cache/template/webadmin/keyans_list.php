<?php include(pe_tpl('header.html','admin'));?>
<div class="right">
	<div class="now">
		<div class="clear"></div>
	</div>
	<div class="right_main">
		<div class="search">
			<form method="get">
				<input type="hidden" name="mod" value="<?php echo $_g_mod ?>" />
				<input type="hidden" name="type" value="<?php echo $_g_type ?>" />
				名称：<input type="text" name="name" value="<?php echo $_g_name ?>" class="inputtext input200" />
				<input type="submit" value="搜索" class="input_btn" />
			</form>
		</div>
		<form method="post" id="form">
		<table width="100%" border="0" cellspacing="0" cellpadding="0" class="list">
		<tr>
			<th class="bgtt" width="20"><input type="checkbox" name="checkall" onclick="pe_checkall(this, 'article_id')" /></th>
			<th class="bgtt" width="50">ID号</th>
			<th class="bgtt aleft">名称</th>
			<th class="bgtt aleft">发布人</th>
			<th class="bgtt" width="120">发布日期</th>
			<th class="bgtt" width="70">状态</th>
			<th class="bgtt" width="120">审核日期</th>
			<th class="bgtt" width="110">操作</th>
		</tr>
		<?php foreach($info_list as $v):?>
		<tr>
			<td><input type="checkbox" name="article_id[]" value="<?php echo $v['article_id'] ?>"></td>
			<td><?php echo $v['article_id'] ?></td>
			<td class="aleft"><?php echo $v['article_name'] ?></td>
		    <td class="aleft"><?php echo $v['users']['admin_name'] ?></td>
			<td class="num"><?php echo pe_date($v['article_atime']) ?></td>
			<td class="num">
			<?php if($v['shenhe'] == 0):?>
            未审核
			<?php endif?>
			<?php if($v['shenhe'] == 1):?>
            通过
			<?php endif?>
			<?php if($v['shenhe'] == 2):?>
            拒绝
			<?php endif?>  
			
			</td>
			<td class="num"><?php echo pe_date($v['article_ptime']) ?></td>
			<td>
				<?php if($v['shenhe'] == 0):?>
				<a href="webadmin.php?mod=keyans&act=success&id=<?php echo $v['article_id'] ?>" class="admin_edit mar3" onclick="return pe_cfone(this, '通过')">通过</a>
				<a href="webadmin.php?mod=keyans&act=refuse&id=<?php echo $v['article_id'] ?>" class="admin_del" onclick="return pe_cfone(this, '拒绝')">拒绝</a>
				<?php endif;?>
			</td>
		</tr>
		<?php endforeach;?>
		</table>
		</form>
	</div>
	<div class="right_bottom">
		<span class="fl mal10">
			<input type="checkbox" name="checkall" onclick="pe_checkall(this, 'article_id')" />
			<button href="webadmin.php?mod=article&act=del&token=<?php echo $pe_token ?>" onclick="return pe_cfall(this, 'article_id', 'form', '批量删除')">批量删除</button>
		</span>
		<span class="fr fenye"><?php echo $db->page->html ?></span>
		<div class="clear"></div>
	</div>
</div>
<script type="text/javascript">
$(function(){
	$("select").change(function(){
		window.location.href = 'webadmin.php' + $(this).find("option:selected").attr("href");
	})
})
</script>
<?php include(pe_tpl('footer.html','admin'));?>