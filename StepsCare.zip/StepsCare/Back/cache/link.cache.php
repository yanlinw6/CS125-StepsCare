<?php
return unserialize('a:1:{i:0;a:4:{s:7:"link_id";s:1:"1";s:9:"link_name";s:18:"逍瑶官方网站";s:8:"link_url";s:23:"http://www.qiye1000.com";s:10:"link_order";s:1:"1";}}');
?>