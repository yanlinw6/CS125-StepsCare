<?php
return unserialize('a:1:{s:1:"J";a:1:{i:4;a:6:{s:8:"brand_id";s:1:"4";s:10:"brand_name";s:6:"九阳";s:10:"brand_logo";s:22:"attachment/brand/4.jpg";s:10:"brand_text";s:6:"九阳";s:10:"brand_word";s:1:"J";s:11:"brand_order";s:1:"0";}}}');
?>