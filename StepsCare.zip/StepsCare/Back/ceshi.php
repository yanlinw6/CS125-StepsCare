<?php
$text=file_get_contents('https://www.lunwendata.com/thesis/2023/161467.html');
 
    //去除换行及空白字符（序列化內容才需使用）
 
    //$text=str_replace(array("/r","/n","/t","/s"), '', $text);
 
    //取出 div 标签且 id 为 PostContent 的內容，并储存至二维数组 $match 中
 
    //preg_match('/]*class="content"[^>]*>(.*?) /si',$text,$match);
	
	
	
	preg_match('/<div[^>]*id=\"content\".*?>.*?<\/div>/ism',$text,$match); 
 
    //打印出match[0]
 
    //print($match[0]);
	$neirong=$match[0];
	 $neirong=iconv("GB2312","UTF-8",$neirong);
	 
	 //$neirong=str_replace('<div class="content" id="content">','',$match[0]);
	 //$neirong=str_replace('</div>','',$neirong);
 
  
 $neirong = str_replace("_", "\_", $neirong); // 把 '_'过滤掉  
    
 $neirong = str_replace("%", "\%", $neirong); // 把' % '过滤掉    
  
 $neirong = nl2br($neirong); // 回车转换    
  
 $neirong= htmlspecialchars($neirong); // html标记转换 
 
 //$neirong = str_replace( '/', "", $neirong);
 
 //$neirong = str_replace( '(', "", $neirong);

//$neirong = str_replace( ')', "", $neirong);

$neirong = str_replace( "'", "", $neirong);

$neirong = str_replace( "'", "", $neirong);
echo $neirong;
?>