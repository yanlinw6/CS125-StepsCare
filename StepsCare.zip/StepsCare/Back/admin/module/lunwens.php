<?php
/**
 * @copyright   2015-2019 逍遥商城 <http://www.qiye1000.com>
 * @creatdate   2012-0501 myllop <myllop@gmail.com>
 */
$menumark = 'lunwens';
pe_lead('hook/cache.hook.php');
switch ($act) {

	//####################// 分类修改 //####################//
	case 'edit':
		$class_id = intval($_g_id);
		
		$info = $db->pe_select('lunwen', array('id'=>$class_id));

		$seo = pe_seo($menutitle='修改分类', '', '', 'admin');
		include(pe_tpl('lunwens_add.html', 'admin'));
	break;


	//####################// 分类列表 //####################//
	default :
		
		
		$sqlwhere .= " order by `id` desc";
	
		

		$info_list = $db->pe_selectall('lunwen', $sqlwhere, '*', array(30, $_g_page));
		$seo = pe_seo($menutitle='文章分类', '', '', 'admin');
		include(pe_tpl('lunwens_list.html','admin'));
	break;
}
?>