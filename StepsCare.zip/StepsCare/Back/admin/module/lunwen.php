<?php
/**
 * @copyright   2015-2019 逍遥商城 <http://www.qiye1000.com>
 * @creatdate   2012-0501 myllop <myllop@gmail.com>
 */
$menumark = 'lunwen';
pe_lead('hook/cache.hook.php');
switch ($act) {
	//####################// 分类添加 //####################//
	case 'add':
		$class_id = intval($_g_id);
		if (isset($_p_pesubmit)) {
			pe_token_match();
			
			$text=file_get_contents($_p_info['url']);
 
    //去除换行及空白字符（序列化內容才需使用）
 
    //$text=str_replace(array("/r","/n","/t","/s"), '', $text);
 
    //取出 div 标签且 id 为 PostContent 的內容，并储存至二维数组 $match 中
 
    //preg_match('/]*class="content"[^>]*>(.*?) /si',$text,$match);
	
	
	
	preg_match('/<div[^>]*id=\"content\".*?>.*?<\/div>/ism',$text,$match); 
 
    //打印出match[0]
 
    //print($match[0]);
	$neirong=$match[0];
	 $neirong=iconv("GB2312","UTF-8",$neirong);

 //$neirong = str_replace("_", "\_", $neirong); // 把 '_'过滤掉  
    
 //$neirong = str_replace("%", "\%", $neirong); // 把' % '过滤掉    
  
 //$neirong = nl2br($neirong); // 回车转换    
  
 //$neirong= htmlspecialchars($neirong); // html标记转换 
 

//$neirong = str_replace( "'", "", $neirong);

//$neirong = str_replace( "'", "", $neirong);

 $neirong = str_replace('<img src="/', '<img src="https://www.lunwendata.com/', $neirong); // 把 '_'过滤掉  

			
		    $_p_info['atime'] =time();
			$_p_info['neirong'] = $neirong;
			$_p_info['admin_id']=$_SESSION['admin_id'];
			if ($db->pe_insert('lunwen', pe_dbhold($_p_info, array('neirong')))) {
			//if ($db->pe_insert('lunwen', pe_dbhold($_p_info))) {
			
				pe_success('添加成功!', 'webadmin.php?mod=lunwen');
			}
			else {
				pe_error('添加失败...');
			}
		}
		$seo = pe_seo($menutitle='添加分类', '', '', 'admin');
		include(pe_tpl('lunwen_add.html','admin'));
	break;
	//####################// 分类修改 //####################//
	case 'edit':
		$class_id = intval($_g_id);
		if (isset($_p_pesubmit)) {
			pe_token_match();
			if ($db->pe_update('lunwen', array('id'=>$class_id), pe_dbhold($_p_info))) {
			
				pe_success('修改成功!', 'webadmin.php?mod=lunwen');
			}
			else {
				pe_error('修改失败...');
			}
		}
		$info = $db->pe_select('lunwen', array('id'=>$class_id));

		$seo = pe_seo($menutitle='修改分类', '', '', 'admin');
		include(pe_tpl('lunwen_add.html', 'admin'));
	break;
	//####################// 分类删除 //####################//
	case 'del':
		pe_token_match();
		$_g_id == 1 && pe_error('网站公告不能删除...');
		if ($db->pe_delete('lunwen', array('id'=>$_g_id))) {
	
			pe_success('删除成功!');
		}
		else {
			pe_error('删除失败...');
		}
	break;

	//####################// 分类列表 //####################//
	default :

		
		if($_SESSION['admin_id']<>1){
		    $sqlwhere .= " and admin_id='{$_SESSION['admin_id']}' order by `id` desc";
		}else{
		    $sqlwhere .= " order by `id` desc";
		}
		

		$info_list = $db->pe_selectall('lunwen', $sqlwhere, '*', array(30, $_g_page));
		
		$seo = pe_seo($menutitle='文章分类', '', '', 'admin');
		include(pe_tpl('lunwen_list.html','admin'));
	break;
}
?>