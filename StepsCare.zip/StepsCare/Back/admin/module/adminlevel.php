<?php
/**
 * @copyright   2015-2019 逍遥商城 <http://www.qiye1000.com>
 * @creatdate   2012-0501 myllop <myllop@gmail.com>
 */
$menumark = 'adminlevel';

$modact_list['用户中心'][] = array('name'=>'用户管理', 'modact'=>'admin', 'menumark'=>'admin');	
$modact_list['用户中心'][] = array('name'=>'用户权限', 'modact'=>'adminlevel', 'menumark'=>'adminlevel');	
$modact_list['控制面板'][] = array('name'=>'网站设置', 'modact'=>'setting|notice|express', 'menumark'=>'setting');
$modact_list['控制面板'][] = array('name'=>'密码修改', 'modact'=>'admins', 'menumark'=>'admins');
$modact_list['论文管理'][] = array('name'=>'论文抓取添加', 'modact'=>'lunwen', 'menumark'=>'lunwen');
$modact_list['论文管理'][] = array('name'=>'论文抓取列表', 'modact'=>'lunwens', 'menumark'=>'lunwens');
$modact_list['内部管理'][] = array('name'=>'科研信息发布', 'modact'=>'keyan', 'menumark'=>'keyan');
$modact_list['内部管理'][] = array('name'=>'科研信息审批', 'modact'=>'keyans', 'menumark'=>'keyans');
$modact_list['内部管理'][] = array('name'=>'成果汇总', 'modact'=>'keyanss', 'menumark'=>'keyanss');
	

switch ($act) {
	//####################// 管理添加 //####################//
	case 'add':
		if (isset($_p_pesubmit)) {
			pe_token_match();
			if (is_array($_p_modact)) {
				foreach ($modact_list as $v) {
					foreach ($v as $vv) {
						if (in_array($vv['modact'], $_p_modact)) {
							$modact_arr[] = $vv['modact'];
							$menumark_arr[] = $vv['menumark'];
						} 
					}
				}
			}
			$_p_info['adminlevel_modact'] = is_array($modact_arr) ? serialize($modact_arr) : '';			
			$_p_info['adminlevel_menumark'] = is_array($menumark_arr) ? serialize($menumark_arr) : '';			
			if ($db->pe_insert('adminlevel', $_p_info)) {
				cache::write('adminlevel');
				pe_success('添加成功!', 'webadmin.php?mod=adminlevel');
			}
			else {
				pe_error('添加失败...');
			}
		}
		$info['adminlevel_modact'] = array();
		$seo = pe_seo($menutitle='添加权限', '', '', 'admin');
		include(pe_tpl('adminlevel_add.html','admin'));
	break;
	//####################// 管理修改 //####################//
	case 'edit':
		$adminlevel_id = intval($_g_id);
		$_g_id == 1 && pe_error('总管理员不能修改...');
		if (isset($_p_pesubmit)) {
			pe_token_match();
			if (is_array($_p_modact)) {
				foreach ($modact_list as $v) {
					foreach ($v as $vv) {
						if (in_array($vv['modact'], $_p_modact)) {
							$modact_arr[] = $vv['modact'];
							$menumark_arr[] = $vv['menumark'];
						} 
					}
				}
			}
			$_p_info['adminlevel_modact'] = is_array($modact_arr) ? serialize($modact_arr) : '';			
			$_p_info['adminlevel_menumark'] = is_array($menumark_arr) ? serialize($menumark_arr) : '';
			if ($db->pe_update('adminlevel', array('adminlevel_id'=>$adminlevel_id), $_p_info)) {
				cache::write('adminlevel');
				pe_success('修改成功!', 'webadmin.php?mod=adminlevel');
			}
			else {
				pe_error('修改失败...');
			}
		}
		$info = $db->pe_select('adminlevel', array('adminlevel_id'=>$adminlevel_id));
		$info['adminlevel_modact'] = $info['adminlevel_modact'] ? unserialize($info['adminlevel_modact']) : array();		
		$seo = pe_seo($menutitle='修改权限', '', '', 'admin');
		include(pe_tpl('adminlevel_add.html','admin'));
	break;
	//####################// 管理删除 //####################//
	case 'del':
		pe_token_match();
		$_g_id == 1 && pe_error('总管理员权限不能删除');
		if ($db->pe_delete('adminlevel', array('adminlevel_id'=>$_g_id))) {
			cache::write('adminlevel');
			pe_success('删除成功!');
		}
		else {
			pe_error('删除失败...');
		}
	break;
	//####################// 管理列表 //####################//
	default:
		$info_list = $db->pe_selectall('adminlevel', '', '*', array(50, $_g_page));
		$tongji['all'] = $db->pe_num('adminlevel');
		$seo = pe_seo($menutitle='管理权限', '', '', 'admin');
		include(pe_tpl('adminlevel_list.html','admin'));
	break;
}
?>