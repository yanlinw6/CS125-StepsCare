<?php
/**
 * @copyright   2015-2019 逍遥商城 <http://www.qiye1000.com>
 * @creatdate   2012-0501 myllop <myllop@gmail.com>
 */
$menumark = 'keyans';
switch ($act) {
//####################// 审核通过 //####################//
	case 'success':
		$cashout_id = is_array($_p_cashout_id) ? $_p_cashout_id : $_g_id;
            $times=time();
			$db->pe_update('keyan', array('article_id'=>$cashout_id), array('shenhe'=>1,'article_stime'=>$times));

		pe_success('审核成功！');
	break;
	//####################// 审核拒绝 //####################//
	case 'refuse':
		
		$cashout_id = is_array($_p_cashout_id) ? $_p_cashout_id : $_g_id;
	        $times=time();
			$db->pe_update('keyan', array('article_id'=>$cashout_id), array('shenhe'=>2,'article_stime'=>$times));
		
		pe_success('拒绝成功！');
	break;
	//####################// 文章列表 //####################//
	default :
		//$sqlwhere = $_g_type ? "b.`class_type` = 'help'" : "b.`class_type` = 'news'";
		$_g_name && $sqlwhere .= " and `article_name` like '%{$_g_name}%'";
		$sqlwhere .= " order by `article_id` desc";

		$info_list = $db->pe_selectall('keyan', $sqlwhere, '*', array(30, $_g_page));
        foreach ($info_list as $k=>$v) {
			$info_list[$k]['users'] = $db->pe_select('admin', array('admin_id'=>$v['admin_id']));
			
		}
		$seo = pe_seo($menutitle='文章列表', '', '', 'admin');
		include(pe_tpl('keyans_list.html','admin'));
	break;
}
?>