<?php
/**
 * @copyright   2015-2019 逍遥商城 <http://www.qiye1000.com>
 * @creatdate   2012-0501 myllop <myllop@gmail.com>
 */
$menumark = 'keyan';
switch ($act) {
	//####################// 文章添加 //####################//
	case 'add':
		if (isset($_p_pesubmit)) {
			pe_token_match();
			$_p_info['admin_id']=$_SESSION['admin_id'];
			$_p_info['article_atime'] = $_p_info['article_atime'] ? strtotime($_p_info['article_atime']) : time();		
			if ($db->pe_insert('keyan', pe_dbhold($_p_info, array('article_text')))) {
				pe_success('添加成功!', 'webadmin.php?mod=keyan');
			}
			else {
				pe_error('添加失败...');
			}
		}
		$seo = pe_seo($menutitle='添加文章', '', '', 'admin');
		include(pe_tpl('keyan_add.html','admin'));
	break;
	//####################// 文章修改 //####################//
	case 'edit':
		$article_id = intval($_g_id);
		if (isset($_p_pesubmit)) {
			pe_token_match();
			$_p_info['article_atime'] = $_p_info['article_atime'] ? strtotime($_p_info['article_atime']) : time();
			if ($db->pe_update('keyan', array('article_id'=>$article_id), pe_dbhold($_p_info, array('article_text')))) {
				pe_success('修改成功!', $_g_fromto);
			}
			else {
				pe_error('修改失败...');
			}
		}
		$info = $db->pe_select('keyan', array('article_id'=>$article_id));
		$seo = pe_seo($menutitle='修改文章', '', '', 'admin');
		include(pe_tpl('keyan_add.html','admin'));
	break;
	//####################// 文章删除 //####################//
	case 'del':
		pe_token_match();
		if ($db->pe_delete('keyan', array('article_id'=>is_array($_p_article_id) ? $_p_article_id : $_g_id))) {
			pe_success('删除成功!');
		}
		else {
			pe_error('删除失败...');
		}
	break;
	//####################// 文章列表 //####################//
	default :
		//$sqlwhere = $_g_type ? "b.`class_type` = 'help'" : "b.`class_type` = 'news'";
		$_g_name && $sqlwhere .= " and `article_name` like '%{$_g_name}%'";
		if($_SESSION['admin_id']<>1){
		    $sqlwhere .= " and admin_id='{$_SESSION['admin_id']}' order by `article_id` desc";
		}else{
		    $sqlwhere .= " order by `article_id` desc";
		}
		

		$info_list = $db->pe_selectall('keyan', $sqlwhere, '*', array(30, $_g_page));
        foreach ($info_list as $k=>$v) {
			$info_list[$k]['users'] = $db->pe_select('admin', array('admin_id'=>$v['admin_id']));
			
		}
		$seo = pe_seo($menutitle='文章列表', '', '', 'admin');
		include(pe_tpl('keyan_list.html','admin'));
	break;
}
?>