<?php
/**
 * @copyright   2015-2019 逍遥商城 <http://www.qiye1000.com>
 * @creatdate   2012-0501 myllop <myllop@gmail.com>
 */
$menumark = 'keyanss';
switch ($act) {
	//####################// 文章修改 //####################//
	case 'edit':
		$article_id = intval($_g_id);
		
		$info = $db->pe_select('keyan', array('article_id'=>$article_id));
		$seo = pe_seo($menutitle='修改文章', '', '', 'admin');
		include(pe_tpl('keyanss_add.html','admin'));
	break;
	//####################// 文章列表 //####################//
	default :
		//$sqlwhere = $_g_type ? "b.`class_type` = 'help'" : "b.`class_type` = 'news'";
		$_g_name && $sqlwhere .= " and `article_name` like '%{$_g_name}%'";
		$sqlwhere .= " order by `article_id` desc";

		$info_list = $db->pe_selectall('keyan', $sqlwhere, '*', array(30, $_g_page));

		$seo = pe_seo($menutitle='文章列表', '', '', 'admin');
		include(pe_tpl('keyanss_list.html','admin'));
	break;
}
?>