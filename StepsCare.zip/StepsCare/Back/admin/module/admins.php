<?php
/**
 * @copyright   2015-2019 逍遥商城 <http://www.qiye1000.com>
 * @creatdate   2012-0501 myllop <myllop@gmail.com>
 */
$menumark = 'admins';
switch ($act) {
	default:
		$admin_id = $_SESSION['admin_id'];
		$info = $db->pe_select('admin', array('admin_id'=>$admin_id));
		if (isset($_p_pesubmit)) {
		    $ym=md5($_p_admin_pw);
		    if($ym<>$info['admin_pw']){pe_error('密码不一致...'.$ym);}
			$_p_admin_pws && $_p_info['admin_pw'] = md5($_p_admin_pws);
			if ($db->pe_update('admin', array('admin_id'=>$admin_id), $_p_info)) {
				pe_success('修改成功!', 'webadmin.php?mod=admins');
			}
			else {
				pe_error('修改失败...');
			}
		}
		
		$seo = pe_seo($menutitle='修改帐号', '', '', 'admin');
		include(pe_tpl('admin_gai.html', 'admin'));

	break;
}
?>