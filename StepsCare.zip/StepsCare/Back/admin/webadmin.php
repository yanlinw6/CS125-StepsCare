<?php
/**
 * @copyright   2015-2019 逍遥商城 <http://www.qiye1000.com>
 * @creatdate   2012-0501 myllop <myllop@gmail.com>
 */
include('../common.php');

$adminmenu[4] = array(
	'headnav' => 'User Center',
	'subnav' => array(
		array('name' => 'Member List', 'menumark' => 'user', 'url' => 'webadmin.php?mod=user'),
		//array('name' => '会员等级', 'menumark' => 'userlevel', 'url' => 'webadmin.php?mod=userlevel'),
		array('name' => 'Administrator', 'menumark' => 'admin', 'url' => 'webadmin.php?mod=admin'),
		array('name' => 'User permissions', 'menumark' => 'adminlevel', 'url' => 'webadmin.php?mod=adminlevel')
	)
);
$adminmenu[1] = array(
	'headnav' => 'SPORT MANAGEMENT',
	'subnav' => array(
		array('name' => '科研信息申报', 'menumark' => 'keyan', 'url' => 'webadmin.php?mod=keyan'),
		array('name' => '科研信息审批', 'menumark' => 'keyans', 'url' => 'webadmin.php?mod=keyans'),
		array('name' => '成果汇总', 'menumark' => 'keyanss', 'url' => 'webadmin.php?mod=keyanss')
	)
);
$adminmenu[2] = array(
	'headnav' => '论文抓取',
	'subnav' => array(
		//array('name' => '论文抓取添加', 'menumark' => 'lunwen', 'url' => 'webadmin.php?mod=lunwen'),
		//array('name' => '论文抓取列表', 'menumark' => 'lunwens', 'url' => 'webadmin.php?mod=lunwens')
	)
);
$adminmenu[6] = array(
	'headnav' => '控制面板',
	'subnav' => array(
		array('name' => '站点设置', 'menumark' => 'setting', 'url' => 'webadmin.php?mod=setting&act=base'),
		array('name' => '密码修改', 'menumark' => 'admins', 'url' => 'webadmin.php?mod=admins'),
		//array('name' => '微信设置', 'menumark' => 'wechat', 'url' => 'webadmin.php?mod=wechat&act=base'),
		//array('name' => '支付设置', 'menumark' => 'payment', 'url' => 'webadmin.php?mod=payment'),
		////array('name' => '导航管理', 'menumark' => 'menu', 'url' => 'webadmin.php?mod=menu'),
		//array('name' => '广告管理', 'menumark' => 'ad', 'url' => 'webadmin.php?mod=ad'),
		//array('name' => '友情链接', 'menumark' => 'link', 'url' => 'webadmin.php?mod=link')
	)
);

$admin = pe_login('admin');
if ($admin['admin_id'] && $mod == 'do' && $act != 'logout') pe_goto('webadmin.php');
if (!$admin['admin_id'] && $mod != 'do') pe_goto('webadmin.php?mod=do&act=login');

//检测管理权限
$cache_adminlevel = cache::get('adminlevel');
if (!in_array($mod, array('index', 'do')) && $admin['adminlevel_id'] != 1) {
	$admin_result = false;
	$adminlevel_modact = unserialize($cache_adminlevel[$admin['adminlevel_id']]['adminlevel_modact']);
	$adminlevel_modact = $adminlevel_modact ? $adminlevel_modact : array();
	foreach ($adminlevel_modact as $v) {
		foreach(explode('|', $v) as $vv) {
			if ("{$mod}-{$act}" == $vv or $mod == $vv) $admin_result = true;
		}
	}
	!$admin_result && pe_error('权限不足...');
}
//检测菜单隐藏
$adminlevel_menumark = $cache_adminlevel[$admin['adminlevel_id']]['adminlevel_menumark'];
$adminlevel_menumark = $adminlevel_menumark ? unserialize($adminlevel_menumark) : array();
foreach ($adminmenu as $k=>$v) {
	foreach ($v['subnav'] as $kk=>$vv) {
		if ($admin['adminlevel_id'] == 1 or in_array($vv['menumark'], $adminlevel_menumark)) {
			$adminmenu[$k]['show'] = true;
			$adminmenu[$k]['subnav'][$kk]['show'] = true;
		}
	}
}


if (in_array("{$mod}.php", pe_dirlist("{$pe['path_root']}admin/module/*.php"))) {
	include("{$pe['path_root']}admin/module/{$mod}.php");
}
pe_result();
?>