<?php
pe_lead('hook/wechat.hook.php');
wechat_bind();
?>