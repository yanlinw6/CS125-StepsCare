<?php
$pe['db_host'] = '127.0.0.1'; //数据库主机地址
$pe['db_name'] = 'ceshi12_xjxubo_c'; //数据库名称
$pe['db_user'] = 'ceshi12_xjxubo_c'; //数据库用户名
$pe['db_pw'] = '5dLWFZR3h7DsNZS5'; //数据库密码
$pe['db_coding'] = 'utf8';
$pe['url_model'] = 'pathinfo_safe'; //url模式,可选项(pathinfo/pathinfo_safe/php)
define('dbpre','xy_'); //数据库表前缀
?>